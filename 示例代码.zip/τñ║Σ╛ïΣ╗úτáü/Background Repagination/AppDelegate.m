//
//  AppDelegate.m
//  Background Repagination
//
//  Created by 张 诚 on 13-4-16.
//  Copyright (c) 2013年 张 诚. All rights reserved.
//

#import "AppDelegate.h"

#import "ViewController.h"

@implementation AppDelegate

- (void)dealloc
{
    [_window release];
    [_viewController release];
    [super dealloc];
}

- (BOOL)application:(UIApplication *)application didFinishLaunchingWithOptions:(NSDictionary *)launchOptions
{
    self.window = [[[UIWindow alloc] initWithFrame:[[UIScreen mainScreen] bounds]] autorelease];
    // Override point for customization after application launch.
    if ([[UIDevice currentDevice] userInterfaceIdiom] == UIUserInterfaceIdiomPhone) {
        self.viewController = [[[ViewController alloc] initWithNibName:@"ViewController_iPhone" bundle:nil] autorelease];
    } else {
        self.viewController = [[[ViewController alloc] initWithNibName:@"ViewController_iPad" bundle:nil] autorelease];
    }
    self.window.rootViewController = self.viewController;
    [self.window makeKeyAndVisible];
    [[UIApplication sharedApplication]registerForRemoteNotificationTypes:(UIRemoteNotificationTypeAlert|UIRemoteNotificationTypeBadge|UIRemoteNotificationTypeSound)];//判断程序是不是由推送服务完成
    if (launchOptions) {
        NSDictionary*pushNotificationKey=[launchOptions objectForKey:UIApplicationLaunchOptionsLocalNotificationKey];//启动本地通知
        if (pushNotificationKey) {
        UIAlertView *alert=[[UIAlertView alloc]initWithTitle:@"推送通知" message:@"这是通过推送窗口启动的程序，可以在这里处理推送内容" delegate:nil cancelButtonTitle:@"知道了" otherButtonTitles:nil , nil];
            [alert show];
            [alert release];
        }
        
    }
    return YES;
}
-(void)application:(UIApplication *)application didRegisterForRemoteNotificationsWithDeviceToken:(NSData *)deviceToken
{
    NSString*token=[NSString stringWithFormat:@"%@",deviceToken];
    NSLog(@"apns->生成的devToken：%@",token);
    //把deviceToken发送到我们的推送服务器
    
//    DeviceSender* sender = [[[DeviceSender alloc]initWithDelegate:self ]autorelease];
//    [sender sendDeviceToPushServer:token ];

}
-(void)application:(UIApplication *)application didFailToRegisterForRemoteNotificationsWithError:(NSError *)error
{
    NSLog(@"apns->注册推送功能时发生错误，错误信息：\n%@",error);
    

}
-(void)application:(UIApplication *)application didReceiveRemoteNotification:(NSDictionary *)userInfo
{
//接受到推送消息，解析处理
    NSLog(@"Napns-> didReceiveRemoteNotification,Receive Data:\n%@",userInfo);
    //把icon上的标记数字设置为0
    application.applicationIconBadgeNumber=0;
   
    if ([[userInfo objectForKey:@"aps"] objectForKey:@"alert"]!=NULL) {
        UIAlertView*alert=[[UIAlertView alloc]initWithTitle:@"**推送消息**" message: [[userInfo objectForKey:@"aps"]objectForKey:@"alert"] delegate:self cancelButtonTitle:@"关闭" otherButtonTitles:@"处理推送内容", nil];
        [alert show];
        [alert release];
    }



}

- (void)applicationWillResignActive:(UIApplication *)application
{
    // Sent when the application is about to move from active to inactive state. This can occur for certain types of temporary interruptions (such as an incoming phone call or SMS message) or when the user quits the application and it begins the transition to the background state.
    // Use this method to pause ongoing tasks, disable timers, and throttle down OpenGL ES frame rates. Games should use this method to pause the game.
}

- (void)applicationDidEnterBackground:(UIApplication *)application
{
    // Use this method to release shared resources, save user data, invalidate timers, and store enough application state information to restore your application to its current state in case it is terminated later. 
    // If your application supports background execution, this method is called instead of applicationWillTerminate: when the user quits.
}

- (void)applicationWillEnterForeground:(UIApplication *)application
{
    // Called as part of the transition from the background to the inactive state; here you can undo many of the changes made on entering the background.
}

- (void)applicationDidBecomeActive:(UIApplication *)application
{
  //滑动打开那个页面
    
}

- (void)applicationWillTerminate:(UIApplication *)application
{
    // Called when the application is about to terminate. Save data if appropriate. See also applicationDidEnterBackground:.
}

@end
