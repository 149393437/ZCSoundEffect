//
//  AppDelegate.h
//  Background Repagination
//
//  Created by 张 诚 on 13-4-16.
//  Copyright (c) 2013年 张 诚. All rights reserved.
//

#import <UIKit/UIKit.h>

@class ViewController;

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;

@property (strong, nonatomic) ViewController *viewController;

@end
