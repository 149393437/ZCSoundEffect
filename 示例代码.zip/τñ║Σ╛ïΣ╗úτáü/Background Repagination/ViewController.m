//
//  ViewController.m
//  Background Repagination
//
//  Created by 张 诚 on 13-4-16.
//  Copyright (c) 2013年 张 诚. All rights reserved.
//

#import "ViewController.h"
#import "ZCSoundEffect.h"

@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad
{
    [super viewDidLoad];
    UIButton*button=[UIButton buttonWithType:UIButtonTypeContactAdd];
    button.frame=CGRectMake(100, 100, 200, 100);
    [self.view addSubview:button];
    [button addTarget:self action:@selector(buttonClick:) forControlEvents:UIControlEventTouchUpInside];
    

}


-(void)buttonClick:(UIButton*)_button
{
    for (int a=0; a<100; a++) {
        NSString *path = [[NSBundle mainBundle] pathForResource:@"CAT2" ofType:@"WAV"];
        [ZCSoundEffect playSoundEffectPath:path];
               sleep(2);
    }
    
    
   }//播放背景音乐




- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
