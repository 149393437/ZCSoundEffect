//
//  main.m
//  Background Repagination
//
//  Created by 张 诚 on 13-4-16.
//  Copyright (c) 2013年 张 诚. All rights reserved.
//

#import <UIKit/UIKit.h>

#import "AppDelegate.h"

int main(int argc, char *argv[])
{
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([AppDelegate class]));
    }
}
